=== CI Period calculator ===
Contributors: calculatorio
Tags: period calculator, menstrual cycle calculator, period tracker, menstrual period calculator, ovulation calculator, menstrual calendar, period prediction, menstruation calculator, menstrual cycle tracker, calculate period
Requires at least: 5.0
Tested up to: 6.4.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

With our free period calculator, you can find out more about your menstrual cycle and accurately predict when your next period will be.

[https://www.calculator.io/period-calculator/](https://www.calculator.io/period-calculator/)

== Usage ==

Add the Period Calculator shortcode to your page, post or sidebar:

`[ci_period_calculator]`

Add the following code to your template where you would like the Period Calculator to appear:

`<?php display_ci_period_calculator(); ?>`

== Screenshots ==

1. The Period Calculator Input Form.
2. The Period Calculator Calculation Results.

== Installation ==

1. Upload the Period Calculator /ci_period_calculator/ folder to the /wp-content/plugins/ directory.
2. Activate the Period Calculator plugin through the "Plugins" menu in WordPress.

== Changelog ==

= 1.0.0 =
* Initial release of Period Calculator
